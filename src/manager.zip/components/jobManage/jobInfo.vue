<template>
    <roomList />
</template>

<script setup>
import roomList from './roomList.vue'
</script>